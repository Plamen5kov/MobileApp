var markers = [];
var images = everlive.data("PictureInfo");
var loadLocation = function () {
    images.get()
        .then(function (data) {
            console.log(data);
            data.result.forEach(function (image) {
               markers.push({
                    "Location": image.Location,
                    //"Content": image.Content
                });
            });
        },
            function (error) {
                console.log(error);
            })
};

function createMap() {
    //loadLocation();
    $("#map").kendoMap({
        center: [40, 25],
        zoom: 6,
        layers: [{
            type: "tile",
            urlTemplate: "http://#= subdomain #.tile.openstreetmap.org/#= zoom #/#= x #/#= y #.png"
        }],
        markers: [{
            location: [43, 23],
            shape: "pinTarget",
            //tooltip: {
            //    content: "Austin, TX"
            //}
        }]
    });
}

$(document).ready(createMap);
//var markers = [];
//var images = everlive.data("PictureInfo");
////var loadLocation = function () {
////    images.get()
////        .then(function (data) {
////            data.result.forEach(function (image) {
////                markers.push({
////                    "location": [image.Location.latitude, image.Location.longitude],
////                    "shape": "pinTarget",
////                    "tooltip": {content: ""}
////                });
////            });
////            console.log(markers);

////        },
////            function (error) {
////                console.log(error);
////            })
////};

//function createMap() {
//    //loadLocation();
//    $("#map").kendoMap({
//        center: [40, 25],
//        zoom: 6,
//        layers: [{
//            type: "tile",
//            urlTemplate: "http://#= subdomain #.tile.openstreetmap.org/#= zoom #/#= x #/#= y #.png"
//        }]
//    });
//}

//$(document).ready(createMap);